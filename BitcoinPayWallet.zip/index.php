<?php 
    session_start();
    header('location: https://bdgroup.co.za/view/');
    die();
?>