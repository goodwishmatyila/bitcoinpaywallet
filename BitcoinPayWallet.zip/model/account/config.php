<?php

//database configuration details
$host = "154.0.170.55";
$user = "gzezd_admin";
$password = "Virtucube123@";
$db = "gzezdpss_home";

//create connection
$conn = mysqli_connect($host,$user,$password,$db);

// Check connection
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}

?>