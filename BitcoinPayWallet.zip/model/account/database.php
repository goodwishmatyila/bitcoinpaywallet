<?php 

//database options
function DatabaseInit($usr,$pwd, $condition)
	{

		include "config.php"; //configuration module
 		
		include "register.php"; //register module 
	
		include "login.php"; //login module
		

		mysqli_close($conn);
 // open database, create sql statements, run the query, catch errors, parse array of results 
	}
?>
  