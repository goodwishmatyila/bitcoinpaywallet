<?php
	//login if condition is equals 1 
	if($condition == 2)
	{
		$sql = "SELECT username, password FROM Customers WHERE username='{$usr}'";
		
		$result = mysqli_query($conn, $sql);
		
		//check number of rows if greater 
		if (mysqli_num_rows($result) > 0) {
    // output data of each row loop through table
			while($row = mysqli_fetch_assoc($result)) {
				 //debug result
				//echo "Your Account: " . $row["username"]. " " . $row["password"]. "<br>";
				
				//validate account against username and password
				if($usr == $row['username'] && $pwd == $row['password']){
					echo "Your details are correct our dashboard not yet ready!";
				}else if($pwd != $row['password']){
					echo "Contact administrator to reset your password!";
				}
				
			}
		} else {
			echo "0 results";
		}
	}
	

?>