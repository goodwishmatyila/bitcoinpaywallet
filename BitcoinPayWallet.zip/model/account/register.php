
<?php
	//create account if condition is equals 1 
	if($condition == 1)
	{
		$sql = "INSERT INTO Customers (username, password)
		VALUES ('{$usr}', '{$pwd}')";

		if (mysqli_query($conn, $sql)) {
			echo "Your account has been registered"; //custom notification
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			Echo "User with this email already registered."; //custom notification
		}
	}
?>