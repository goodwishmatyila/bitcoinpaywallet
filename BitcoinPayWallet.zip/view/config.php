<?php

//database configuration details
$host = "localhost";
$user = "bdgroasn_acc";
$password = "";
$db = "bdgroasn_clients";

//create connection
$conn = mysqli_connect($host,$user,$password,$db);

// Check connection
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}else{
    
   // echo "Connection success!";
}

?>