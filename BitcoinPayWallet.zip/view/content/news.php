<div style="background-color:; padding:10px;">
    
      <b>What we pride ourselves for</b><br/>
          <p>
              We provide medium to large scale advertising, marketing business leads to all industries, We employ over 200 promoters, marketing gurus, freelance designers for creatives. We also partnered with large marketing companies in South Africa.
          </p>
          <br />
           <h3>Gain Experience</h3>
           <b>Diversify your knowledge</b><br/>
          <p>
              One will have plenty of experience in social media, adwords, creative, perfomance marketing through sms, email, websites, banners, displays, content inline advertising, publishing online, ppc, cpa, cpc marketing.<br/>
              Increase your experience by joining us short-tem contracts.
          </p>
            <br />
            <h3>Legal & Documentation</h3>
       
          </p>
          
    <h3>Business information</h3>
    <p>
        Business Registration <br/>
        2016/135921/07<br/>


        Business Tax Number<br/>
        9174400227<br/>
        
        Postal Address<br/>
        3763 Bluegum Road<br/>
        Vereeniging<br/>
        1930<br/>
        
        <p>
             <a href="mailto:admin@bdgroup.co.za"> Email &#8677; Management </a>
        </p>
         <p>
             <a href="mailto:helpdesk@bdgroup.co.za"> Email &#8677; Customer Services </a>
        </p>
         <p>
             <a href="mailto:info@bdgroup.co.za"> Email &#8677; Information Desk </a>
        </p>
        <p>
            
        BD Group has launched it's website on the 09/04/2016 
        was developed by G.Matyila working on the project that has been
        on his heart since 2007. This project was the most important project from the start
        it made Mr.G.Matyila learn to push limits at all costs <br/>
        </p>
       
        
        <ul>
            <li>Capehost Netherlands, www.capehost.nl</li>
            <li>Dyfensive Cryptographic Security Pty Ltd</li>
            <li>Shieldhost &trade; Defence</li>
            <li>Virtucube &trade;</li>
        </ul>
        <p>
            Without doubt lots of hardwork
        BD Group was launched to internet audience through major social network platforms
        Paying for links, other traffic that BD Group received from partner sites.
        
        The "company" has legaly registered freely show the above "company registration"
        to help those that need to verify the "legal status" of the "company" herein which refers to
        "BD GROUP PTY LTD" and other associated trade names which are as follows:<br/>
        </p>
    </p>
</div>