 <dl class="adr">
            <dt class="clr-1"><strong>BD Group Pty Limited</strong></dt>
            <br/>
            <img src="//bdgroup.co.za/view/images/director.PNG" alt="Managing Director"width="50" style="border-style:solid;"/>
            <br/>
            <dd><strong>Mr. G. Matyila (Director)</strong></dd>
            <dd><span>Telephone:</span><strong>+27 87 822-1770</strong></dd>
        
            <dd><span>Email:</span><a href="#" class="link">info@bdgroup.co.za</a></dd>
            <dd>&nbsp;</dd>
             <img src="//bdgroup.co.za/view/images/admin.PNG" alt="Administrative Clerk"width="50" style="border-style:solid;"/>
            <br/>
            <br/>
            <dd><strong>Mrs. N. Matyila(Secretary)</strong></dd>
            <dd><span>Telephone:</span><strong>+27 87 822-1770</strong></dd>
            
             <dd>&nbsp;</dd>
             <img src="//bdgroup.co.za/view/images/user-512.png" alt="Accounts Manager"width="50" style="border-style:solid;"/>
            <br/>
            <br/>
            <dd><strong>Mrs. T. Matyila(Admin)</strong></dd>
            <dd><span>Telephone:</span><strong>+27 87 822-1770</strong></dd>
       
            <dd><span>Email:</span><a href="#" class="link">thembi.m@bdgroup.co.za</a></dd>
            
             <dd>&nbsp;</dd>
             <img src="//bdgroup.co.za/view/images/user-512.png" alt="Accounts Manager"width="50" style="border-style:solid;"/>
            <br/>
            <br/>
            <dd><strong>Mr Mxolisi Aadil(Accounts)</strong></dd>
            <dd><span>Telephone:</span><strong>+27 87 822-1770</strong></dd>
       
            <dd><span>Email:</span><a href="#" class="link">billing@bdgroup.co.za</a></dd>
            
             <dd>&nbsp;</dd>
             <img src="//bdgroup.co.za/view/images/user-512.png" alt="Accounts Manager"width="50" style="border-style:solid;"/>
            <br/>
            <br/>
            <dd><strong>Mrs. Sthembiso Matyila(Sales)</strong></dd>
            <dd><span>Telephone:</span><strong>+27 87 822-1770</strong></dd>
       
            <dd><span>Email:</span><a href="#" class="link">sales@bdgroup.co.za</a></dd>
</dl>