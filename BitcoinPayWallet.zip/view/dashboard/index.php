<?php
 
   
   //GLOBALS ACCOUNT
   
   $AccountBalance = 0.00;
   
 
   session_start(); //session start caching
   
   //session end on logout 
   if($_POST['account'] == 'logout')
   {
       session_destroy(); //destroy current user session on logout
       
       header("location: http://bdgroup.co.za/view/"); //redirect to home
       
       //die();
   }
   
   //validated user logged in state from session cookie
   if( !isset($_SESSION['username']) && !isset($_SESSION['username']) )
   {
       header("location: http://bdgroup.co.za/view/?nav=error");
       die();
   }
   $client_user = $_SESSION['username']; //retrieve username
   $client_password = $_SESSION['password']; //retrieve password
   
   //class to manage account
   
   
   class CheckBalance
   {
       public static function GetAmount()
       {
           
           
           
//database configuration details
$host = "localhost";
$user = "bdgroasn_acc";
$password = "gsm78692@";
$db = "bdgroasn_clients";

//create connection
$conn = mysqli_connect($host,$user,$password,$db);

// Check connection
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}else{
    
   //echo "Connection success!";
}
           
           $profile = base64_decode($_GET['profile']);
           $sql = "SELECT balance FROM Customers WHERE username='{$profile}'";
           
           $queryResult = mysqli_query($conn, $sql);
           
           if(mysqli_num_rows($queryResult) > 0)
           {
               while( $row = mysqli_fetch_assoc($queryResult) )
               {
                   echo $row['balance']; //balance
                  
               }
           }
           
           mysqli_close($conn); //close connection 
       }
   }
   
   
   
   
   class EmailNotify{
       
       public static function CashRequest()
       {
           //send email to client 
           
           //send email to company
       }
   }
   
   class Banking
   {
       public static function ChangeBankingDetails()
       {
           
       }
       public static function UpdateBankingDetails()
       {
           
       }
   }
   
   class AccountManager
   {
       //widthdraw money @param amount
       public static function Withdraw($amount)
       {
            //cash notification
            
        
          
            
       }
       //tranfer money @param amount
       public static function Transfer($amount)
       {
           //cash notification
           
           //update database
       }
       
   }
   
   
    
?>
      
            
            <div class="container container-fluid jumbotron ">
                
                <h1><i class="fa fa-credit-card" aria-hidden="true"></i>
 My Wallet </h1>
                
                <p>
                    Manage your wallet with us keep your password and username safe.
                    
                </p>
                <br />
                 <div class="row">
                    <div class="col-md-6">
                        <h3 class="lead"> <i class="fa fa-envelope"></i> Registered Email</h3>
                           <?php echo $client_user; ?>
                    </div>
                    <div class="col-md-6">
                        <h3 class="lead"><i class="fa fa-info"></i> Status</h3>
                            Account Status: <input type="checkbox" checked disabled readonly/> Active | <input type="checkbox" disabled readonly/> Not Active<br/>
                    </div>
                    
                </div>
            
                
                <br />
                
               <div style="height:100px;">
                   
            
               </div>
               <h3 class="lead"> <i class="fa fa-globe"></i> Account Navigator</h3>
               <br/>
               <table border="3" class="well">
                   <div class="row">
                       <div class="col-md-4">
                           <b>Balance</b>
                       </div>
                       <div class="col-md-4">
                           R <span id="account-balance"> <?php echo CheckBalance::GetAmount(); ?> </span>
                       </div>
                         <div class="col-md-4">
                             <script>
                                 function GetMoney(money)
                                 {
                                     var t = document.querySelector('#account-balance').innerHTML;
                                     swal({
                                         title: "Cash Withdrawal",
                                         text: "Your cash withdrawal R "+ parseFloat(t).toFixed(2) +" request has been filed will be processed within 48 hours",
                                         icon: "success"
                                     });
                                     return 1;
                                 }(67)
                             </script>
                           <button onclick="javascript:GetMoney();" class="get-money btn btn-success btn-lg"><i class="fa fa-cash"></i> Withdraw Funds</button>
                       </div>
                   </div>
                   
                 
                   
               </table>
               <small>Payments/Withdrawal take upto 2-3 Business days from time of request. Excludes public holidays. </small> <br/>
               <br/>
                 <form method="POST" action="/">
                       <input type="hidden" value="logout" name="account">
                       <button type="submit" class="btn btn-danger btn-lg"  style="background-style:solid; background-width:0.2px;" ><i class="fa fa-sign-out"></i> Logout</button>
                  </form>
            </div>

  <script>
      /* G. Matyila , A BD Group Pty Ltd, Project 2017 */
      
      //GLOBAL VARIABLES
      var ACCOUNT_BALANCE;
      var ACCOUNT_WITHDRAW;
      var ACCOUNT_TRANSFER;
      var ACCOUNT_DETAILS;
      var ACCOUNT_NOTIFICATION;
      var ACCOUNT_TRANSACTIONS;
      var ACCOUNT_UPDATE;
      var ACCOUNT_DELETE;
      var ACCOUNT_STATEMENT;
      var ACCOUNT_PROFILE;
      
      //ACCOUNT NOTIFICATIONS
      ACCOUNT_NOTIFICATIONS = {
          "busy": "Transaction response from the server has returned with busy status",
          "processed" :"Transaction has been processed",
          "delayed" :"Transaction has be put on hold for verifications",
          "cancelled": "Transaction has be cancelled due to verification",
          "fica": "FICA documentation is required for approval"
      };
      
      swal({
          title:"Welcome",
          text:ACCOUNT_NOTIFICATIONS['fica']
      });
      
      
  </script>