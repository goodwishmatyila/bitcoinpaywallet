<?php
    //database
    include "database.php";
    
    //require dependencies
    require 'template/header.tpl';
    
    //require content , via route 
    require 'router.php';
    
    //require footer 
    require 'template/footer.tpl';

    //test
   // DatabaseInit("goodwish","gsm999", 1);
?>