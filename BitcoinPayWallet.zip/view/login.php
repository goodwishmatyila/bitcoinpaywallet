<?php
	//login if condition is equals 1 
	if($condition == 2)
	{
		$sql = "SELECT username, password FROM Customers WHERE username='{$usr}'";
		
		$result = mysqli_query($conn, $sql);
		
		//check number of rows if greater 
		if (mysqli_num_rows($result) > 0) {
    // output data of each row loop through table
			while($row = mysqli_fetch_assoc($result)) {
				 //debug result
				//echo "Your Account: " . $row["username"]. " " . $row["password"]. "<br>";
				$keyuser = base64_encode($row['username']);
				$keypwd = base64_encode($row['password']);
				
			    //session start to maintain state.
                session_start();
                $_SESSION['username']= $row["username"];
                $_SESSION['password']= $row["password"];

                $profile_auth = base64_encode($usr);
				
				$keyid = $keyuser.$keypwd; //session cookie out of base64-
				//validate account against username and password
				if($usr == $row['username'] && $pwd == $row['password']){
				    printf("%s", "<script> location.href='?nav=dashboard&sessionui={$keyid}&profile={$profile_auth}' </script>");
				}else if($pwd != $row['password']){
					echo "Invalid login details ,Contact administrator to reset your password!";
					echo "<script>swal({
					    'title':'Invalid Login Details',
					    'text':'Kindly SMS your ID number and ID copy via helpdesk@bdgroup.co.za to restore your account, If you forgot your password kindly phone us 087 822-1770',
					    'icon':'warning'
					})</script>";
				}
				
			}
		} else {
			echo "0 results";
		}
	}
	

?>