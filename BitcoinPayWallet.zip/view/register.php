
<?php
	//create account if condition is equals 1 
	if($condition == 1)
	{
		$sql = "INSERT INTO Customers (username, password)
		VALUES ('{$usr}', '{$pwd}')";

		if (mysqli_query($conn, $sql)) {
			echo "<script>swal({'title':'Register Success','text':'Your account has been successfully registered','icon':'success'})</script>Your account has been registered"; //custom notification
		
		    echo "<script>swal({'title':'Welcome to Wallet Saver',
		        'text':'BD Group Bitcoin Pay Wallet lets you invest in CryptoCurrencies for financial growth instantly after registering your account with our platform that is trustworthy in South Africa, Our platform uses SSL to secure your communication online all transactions on the platform are handled by Payfast Gateway Services for PCI compliant financial payment gateway to ensure safety of your money and paper trail for your investments to track your funds and invest more for growth','icon':'success'
		    })</script>";
		} else {
			//echo "Error: " . $sql . "<br>" . mysqli_error($conn);
			Echo "User with this email already registered."; //custom notification
			$errorDisplayUser = "<script> swal({
			    'title':'Error Registering',
			    'text':'This user already registered on our system',
			    'icon':'warning'
			}) </script>";
			echo $errorDisplayUser;
		}
	}
?>