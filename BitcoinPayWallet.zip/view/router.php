
<?php 

//Handle route req from client-side
function RouteMap($path)
{
    if($path == "account"){
        //account section
        include "content/login.tpl";
    }else if($path == "company"){
        //contact section
        include "content/company.tpl";
    }else if($path == "dashboard"){
        //loging to client area
        include "dashboard/index.php";
    }else if($path == "quotes"){
        //quote
        include "content/services.tpl";
    }else{
        //default section
        include "content/default.tpl";
    }
}

//init route @param 
RouteMap($_GET['nav']);
?>